import React, { useState, useEffect } from "react";
import {
  Search,
  Calculator,
  Database,
  Save,
  Settings,
  CheckCircle2,
  Download,
  Upload,
  Trash2,
  Edit,
  X,
} from "lucide-react";

const RetificadoraApp = () => {
  const [activeTab, setActiveTab] = useState("consulta");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedMotor, setSelectedMotor] = useState(null);

  const [tipoRetifica, setTipoRetifica] = useState("biela");
  const [medidaAtual, setMedidaAtual] = useState("");
  const [medidaCorte, setMedidaCorte] = useState("");
  const [resultadoCalc, setResultadoCalc] = useState(null);

  const [novoMotor, setNovoMotor] = useState({
    marca: "",
    carro: "",
    motor: "",
    fixo: "",
    biela: "",
    lateral: "",
    curso: "",
    mancal: "",
    diametro: "",
    altura: "",
    ferro: "",
  });

  const [editandoMotor, setEditandoMotor] = useState(null);
  const [mostrarFormEdicao, setMostrarFormEdicao] = useState(false);

  // 🔥 DADOS PERSISTENTES - Carrega do localStorage
  const [motores, setMotores] = useState(() => {
    const saved = localStorage.getItem("retificadora-motores");
    if (saved) {
      return JSON.parse(saved);
    }

    // Dados iniciais
    return [
      {
        id: 1,
        marca: "PALIO/UNO/SIENA",
        carro: "FIRE 1.0 141C2000",
        motor: "48,00",
        fixo: 38.0,
        biela: 24.0,
        lateral: 32.45,
        curso: 21.0,
        mancal: "78,70",
        diametro: "70,00X64,90",
        altura: "41,12/41,14",
        ferro: "70,00",
      },
      {
        id: 2,
        marca: "PALIO/UNO/SIENA",
        carro: "FIRE 1.3 169A4000",
        motor: "48,00",
        fixo: 42.0,
        biela: 24.0,
        lateral: 39.45,
        curso: 24.0,
        mancal: "81,35",
        diametro: "70,80X78,90",
        altura: "45,12/45,14",
        ferro: "70,80",
      },
    ];
  });

  // 🔥 SALVAR SEMPRE QUE MOTORES MUDAR
  useEffect(() => {
    localStorage.setItem("retificadora-motores", JSON.stringify(motores));
  }, [motores]);

  // 📤 EXPORTAR PARA EXCEL/CSV
  const exportarParaExcel = () => {
    if (motores.length === 0) {
      alert("❌ Nenhum dado para exportar!");
      return;
    }

    const headers = [
      "ID",
      "MARCA",
      "CARRO",
      "MOTOR",
      "FIXO",
      "BIELA",
      "LATERAL",
      "CURSO",
      "MANCAL",
      "DIAMETRO",
      "ALTURA",
      "FERRO",
    ];

    const csvData = motores.map((motor) => [
      motor.id,
      motor.marca,
      motor.carro,
      motor.motor,
      motor.fixo,
      motor.biela,
      motor.lateral,
      motor.curso,
      motor.mancal,
      motor.diametro,
      motor.altura,
      motor.ferro,
    ]);

    const csvContent = [headers, ...csvData]
      .map((row) => row.map((cell) => `"${cell}"`).join(","))
      .join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);

    link.setAttribute("href", url);
    link.setAttribute(
      "download",
      `eixos-virabrequim-${new Date().toISOString().split("T")[0]}.csv`
    );
    link.style.visibility = "hidden";

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    alert(`✅ ${motores.length} motores exportados para CSV/Excel!`);
  };

  // 📥 IMPORTAR DE EXCEL/CSV
  const importarDeExcel = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const csvText = e.target.result;
        const lines = csvText.split("\n");

        const novosMotores = [];
        let maxId = Math.max(...motores.map((m) => m.id), 0);

        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;

          const cells = line
            .split(",")
            .map((cell) => cell.replace(/^"|"$/g, "").trim());

          if (cells.length >= 5) {
            maxId++;
            novosMotores.push({
              id: maxId,
              marca: cells[1] || "Sem marca",
              carro: cells[2] || "Sem carro",
              motor: cells[3] || "Sem motor",
              fixo: parseFloat(cells[4]) || 0,
              biela: parseFloat(cells[5]) || 0,
              lateral: parseFloat(cells[6]) || 0,
              curso: parseFloat(cells[7]) || 0,
              mancal: cells[8] || "",
              diametro: cells[9] || "",
              altura: cells[10] || "",
              ferro: cells[11] || "",
            });
          }
        }

        if (novosMotores.length > 0) {
          setMotores([...motores, ...novosMotores]);
          alert(`✅ ${novosMotores.length} motores importados do CSV!`);
        } else {
          alert("❌ Nenhum motor válido encontrado no arquivo.");
        }
      } catch (error) {
        alert("❌ Erro ao importar arquivo. Verifique o formato.");
        console.error("Erro importação:", error);
      }
    };

    reader.readAsText(file);
    event.target.value = "";
  };

  // 📋 GERAR PLANILHA MODELO
  const gerarModeloPlanilha = () => {
    const modelo = [
      [
        "ID",
        "MARCA",
        "CARRO",
        "MOTOR",
        "FIXO",
        "BIELA",
        "LATERAL",
        "CURSO",
        "MANCAL",
        "DIAMETRO",
        "ALTURA",
        "FERRO",
      ],
      [
        "1",
        "PALIO/UNO/SIENA",
        "FIRE 1.0 141C2000",
        "48,00",
        "38.00",
        "24.00",
        "32.45",
        "21.00",
        "78,70",
        "70,00X64,90",
        "41,12/41,14",
        "70,00",
      ],
      [
        "2",
        "PALIO/UNO/SIENA",
        "FIRE 1.3 169A4000",
        "48,00",
        "42.00",
        "24.00",
        "39.45",
        "24.00",
        "81,35",
        "70,80X78,90",
        "45,12/45,14",
        "70,80",
      ],
    ];

    const csvContent = modelo
      .map((row) => row.map((cell) => `"${cell}"`).join(","))
      .join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);

    link.setAttribute("href", url);
    link.setAttribute("download", "modelo-planilha-eixos.csv");
    link.style.visibility = "hidden";

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    alert("📋 Modelo de planilha baixado! Preencha e importe.");
  };

  // 🔧 CADASTRAR NOVO MOTOR
  const salvarMotor = () => {
    if (
      !novoMotor.marca ||
      !novoMotor.carro ||
      !novoMotor.motor ||
      !novoMotor.biela ||
      !novoMotor.curso
    ) {
      alert("❌ Preencha os campos obrigatórios!");
      return;
    }

    const novoId = Math.max(...motores.map((m) => m.id), 0) + 1;

    const motorParaSalvar = {
      id: novoId,
      marca: novoMotor.marca,
      carro: novoMotor.carro,
      motor: novoMotor.motor,
      fixo: parseFloat(novoMotor.fixo) || 0,
      biela: parseFloat(novoMotor.biela),
      lateral: parseFloat(novoMotor.lateral) || 0,
      curso: parseFloat(novoMotor.curso),
      mancal: novoMotor.mancal || "",
      diametro: novoMotor.diametro || "",
      altura: novoMotor.altura || "",
      ferro: novoMotor.ferro || "",
    };

    setMotores([...motores, motorParaSalvar]);
    setNovoMotor({
      marca: "",
      carro: "",
      motor: "",
      fixo: "",
      biela: "",
      lateral: "",
      curso: "",
      mancal: "",
      diametro: "",
      altura: "",
      ferro: "",
    });

    alert("✅ Motor cadastrado e salvo!");
    setActiveTab("consulta");
  };

  // ✏️ EDITAR MOTOR
  const iniciarEdicao = (motor) => {
    setEditandoMotor(motor);
    setNovoMotor({
      marca: motor.marca,
      carro: motor.carro,
      motor: motor.motor,
      fixo: motor.fixo,
      biela: motor.biela,
      lateral: motor.lateral,
      curso: motor.curso,
      mancal: motor.mancal,
      diametro: motor.diametro,
      altura: motor.altura,
      ferro: motor.ferro,
    });
    setActiveTab("cadastro"); // 🔥 VAI PARA ABA CADASTRO
  };

  const salvarEdicao = () => {
    if (
      !novoMotor.marca ||
      !novoMotor.carro ||
      !novoMotor.motor ||
      !novoMotor.biela ||
      !novoMotor.curso
    ) {
      alert("❌ Preencha os campos obrigatórios!");
      return;
    }

    const motorEditado = {
      ...editandoMotor,
      marca: novoMotor.marca,
      carro: novoMotor.carro,
      motor: novoMotor.motor,
      fixo: parseFloat(novoMotor.fixo) || 0,
      biela: parseFloat(novoMotor.biela),
      lateral: parseFloat(novoMotor.lateral) || 0,
      curso: parseFloat(novoMotor.curso),
      mancal: novoMotor.mancal || "",
      diametro: novoMotor.diametro || "",
      altura: novoMotor.altura || "",
      ferro: novoMotor.ferro || "",
    };

    setMotores(
      motores.map((m) => (m.id === editandoMotor.id ? motorEditado : m))
    );
    setEditandoMotor(null);
    setMostrarFormEdicao(false);
    setNovoMotor({
      marca: "",
      carro: "",
      motor: "",
      fixo: "",
      biela: "",
      lateral: "",
      curso: "",
      mancal: "",
      diametro: "",
      altura: "",
      ferro: "",
    });

    alert("✅ Motor editado com sucesso!");
  };

  const cancelarEdicao = () => {
    setEditandoMotor(null);
    setMostrarFormEdicao(false);
    setNovoMotor({
      marca: "",
      carro: "",
      motor: "",
      fixo: "",
      biela: "",
      lateral: "",
      curso: "",
      mancal: "",
      diametro: "",
      altura: "",
      ferro: "",
    });
    setActiveTab("consulta");
  };

  // 🗑️ EXCLUIR MOTOR
  const excluirMotor = (id, event) => {
    event.stopPropagation();

    if (window.confirm("Tem certeza que deseja excluir este motor?")) {
      setMotores(motores.filter((motor) => motor.id !== id));
      if (selectedMotor?.id === id) {
        setSelectedMotor(null);
      }
      alert("✅ Motor excluído!");
    }
  };

  // 🔍 BUSCA LOCAL
  const motoresFiltrados = motores.filter(
    (motor) =>
      motor.marca.toLowerCase().includes(searchTerm.toLowerCase()) ||
      motor.carro.toLowerCase().includes(searchTerm.toLowerCase()) ||
      motor.motor.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // 🧮 CÁLCULOS DA CALCULADORA
  useEffect(() => {
    if (selectedMotor && medidaAtual) {
      const medidaStd =
        tipoRetifica === "biela"
          ? selectedMotor.biela
          : parseFloat(selectedMotor.mancal.split("/")[0]);
      const atual = parseFloat(medidaAtual);

      if (atual && atual < medidaStd) {
        const diferencaAtual = medidaStd - atual;
        const medidasPossiveis = [0.25, 0.5, 0.75, 1.0];

        for (let medida of medidasPossiveis) {
          if (diferencaAtual < medida) {
            setMedidaCorte((medidaStd - medida).toFixed(2));
            return;
          }
        }
        setMedidaCorte((medidaStd - 1.0).toFixed(2));
      }
    }
  }, [medidaAtual, selectedMotor, tipoRetifica]);

  const calcularDeslocamento = () => {
    if (!selectedMotor || !medidaAtual || !medidaCorte) {
      alert("Preencha todos os campos");
      return;
    }

    const medidaStd =
      tipoRetifica === "biela"
        ? selectedMotor.biela
        : parseFloat(selectedMotor.mancal.split("/")[0]);
    const atual = parseFloat(medidaAtual);
    const corte = parseFloat(medidaCorte);

    const deslocamento = medidaStd - corte;
    const contraPeso = selectedMotor.curso;

    setResultadoCalc({
      tipo: tipoRetifica === "biela" ? "BIELA" : "MANCAL",
      medidaStd: medidaStd.toFixed(2),
      medidaAtual: atual.toFixed(2),
      medidaCorte: corte.toFixed(2),
      deslocamento: deslocamento.toFixed(2),
      contraPeso: contraPeso.toFixed(2),
      curso: selectedMotor.curso.toFixed(2),
    });
  };

  // 🔥 ESTILOS
  const styles = {
    container: {
      minHeight: "100vh",
      background:
        "linear-gradient(135deg, #0f172a 0%, #1e3a8a 50%, #0f172a 100%)",
      color: "white",
      padding: "20px",
      fontFamily: "Arial, sans-serif",
    },
    header: {
      background: "linear-gradient(90deg, #2563eb 0%, #4f46e5 100%)",
      borderRadius: "12px",
      padding: "20px",
      marginBottom: "20px",
      textAlign: "center",
    },
    title: {
      fontSize: "1.5rem",
      fontWeight: "bold",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "12px",
      margin: 0,
    },
    subtitle: {
      color: "#dbeafe",
      fontSize: "0.875rem",
      marginTop: "4px",
      margin: 0,
    },
    tabs: {
      display: "flex",
      gap: "10px",
      marginBottom: "20px",
      flexWrap: "wrap",
    },
    tab: {
      padding: "12px 16px",
      borderRadius: "8px",
      fontWeight: "600",
      border: "none",
      color: "white",
      cursor: "pointer",
      fontSize: "14px",
      display: "flex",
      alignItems: "center",
      gap: "8px",
    },
    tabActive: {
      backgroundColor: "#2563eb",
    },
    tabInactive: {
      backgroundColor: "#374151",
    },
    card: {
      backgroundColor: "#1f2937",
      borderRadius: "12px",
      padding: "20px",
      marginBottom: "20px",
    },
    input: {
      width: "100%",
      padding: "12px",
      backgroundColor: "#374151",
      borderRadius: "8px",
      color: "white",
      border: "2px solid #4b5563",
      outline: "none",
      fontSize: "14px",
      marginBottom: "12px",
    },
    button: {
      padding: "12px 16px",
      borderRadius: "8px",
      fontWeight: "600",
      border: "none",
      cursor: "pointer",
      fontSize: "14px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "8px",
    },
    buttonSuccess: {
      backgroundColor: "#059669",
      color: "white",
    },
    buttonExport: {
      backgroundColor: "#7c3aed",
      color: "white",
    },
    buttonImport: {
      backgroundColor: "#d97706",
      color: "white",
    },
    buttonEdit: {
      backgroundColor: "#d97706",
      color: "white",
      padding: "6px 12px",
      fontSize: "12px",
    },
    buttonDanger: {
      backgroundColor: "#dc2626",
      color: "white",
      padding: "6px 12px",
      fontSize: "12px",
    },
    searchContainer: {
      position: "relative",
      marginBottom: "15px",
    },
    searchIcon: {
      position: "absolute",
      left: "12px",
      top: "50%",
      transform: "translateY(-50%)",
      color: "#9ca3af",
    },
    motorCard: {
      backgroundColor: "#1f2937",
      borderRadius: "12px",
      padding: "20px",
      marginBottom: "15px",
      cursor: "pointer",
      border: "2px solid transparent",
      transition: "all 0.3s",
    },
    motorSelected: {
      borderColor: "#3b82f6",
      boxShadow: "0 0 0 2px rgba(59, 130, 246, 0.5)",
    },
    motorHeader: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      marginBottom: "15px",
    },
    motorMarca: {
      fontSize: "1.2rem",
      fontWeight: "bold",
      color: "#60a5fa",
      margin: "0 0 5px 0",
    },
    motorCarro: {
      color: "#9ca3af",
      fontSize: "0.9rem",
      margin: "0 0 3px 0",
    },
    motorMotor: {
      color: "#d1d5db",
      fontSize: "0.8rem",
      margin: 0,
    },
    metricsGrid: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: "10px",
    },
    metricCard: {
      background: "linear-gradient(135deg, #059669 0%, #047857 100%)",
      borderRadius: "8px",
      padding: "10px",
      textAlign: "center",
    },
    metricBiela: {
      background: "linear-gradient(135deg, #eab308 0%, #d97706 100%)",
    },
    metricCurso: {
      background: "linear-gradient(135deg, #a855f7 0%, #ec4899 100%)",
    },
    metricLabel: {
      display: "block",
      fontSize: "0.75rem",
      fontWeight: "600",
      color: "rgba(255,255,255,0.9)",
      marginBottom: "3px",
    },
    metricValue: {
      fontWeight: "bold",
      fontSize: "1.3rem",
      color: "white",
    },
    formGrid: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
      gap: "15px",
      marginBottom: "20px",
    },
    status: {
      backgroundColor: "#065f46",
      color: "#d1fae5",
      padding: "15px",
      borderRadius: "8px",
      textAlign: "center",
      fontWeight: "600",
      marginBottom: "20px",
    },
    fileInput: {
      display: "none",
    },
    exportButtons: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "10px",
      marginBottom: "15px",
    },
    motorActions: {
      display: "flex",
      gap: "8px",
    },
    calcInfo: {
      backgroundColor: "#1e40af",
      borderRadius: "8px",
      padding: "15px",
      marginBottom: "15px",
    },
    calcInfoRow: {
      display: "flex",
      justifyContent: "space-between",
      marginBottom: "8px",
    },
    calcInfoLabel: {
      color: "#dbeafe",
      fontWeight: "600",
    },
    calcInfoValue: {
      color: "#fef3c7",
      fontWeight: "bold",
    },
  };

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <h1 style={styles.title}>
          <Settings size={32} />
          Retífica de Virabrequim Pro
        </h1>
        <p style={styles.subtitle}>
          📊 {motores.length} motores cadastrados • 💾 Dados salvos
          automaticamente
        </p>
      </div>

      {/* Status */}
      <div style={styles.status}>
        ✅ Sistema completo! Edição, cálculo e persistência funcionando.
      </div>

      {/* Tabs */}
      <div style={styles.tabs}>
        <button
          onClick={() => setActiveTab("consulta")}
          style={{
            ...styles.tab,
            ...(activeTab === "consulta"
              ? styles.tabActive
              : styles.tabInactive),
          }}
        >
          <Database size={18} />
          Consulta
        </button>
        <button
          onClick={() => setActiveTab("calculadora")}
          style={{
            ...styles.tab,
            ...(activeTab === "calculadora"
              ? styles.tabActive
              : styles.tabInactive),
          }}
        >
          <Calculator size={18} />
          Calculadora
        </button>
        <button
          onClick={() => setActiveTab("cadastro")}
          style={{
            ...styles.tab,
            ...(activeTab === "cadastro"
              ? styles.tabActive
              : styles.tabInactive),
          }}
        >
          <Save size={18} />
          Cadastro
        </button>
      </div>

      {/* CONSULTA */}
      {activeTab === "consulta" && (
        <div>
          <div style={styles.card}>
            <div style={styles.searchContainer}>
              <Search size={20} style={styles.searchIcon} />
              <input
                type="text"
                placeholder="Buscar por marca, carro ou motor..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                style={{ ...styles.input, paddingLeft: "40px" }}
              />
            </div>

            {/* Botões de Exportação/Importação */}
            <div style={styles.exportButtons}>
              <button
                onClick={exportarParaExcel}
                disabled={motores.length === 0}
                style={{
                  ...styles.button,
                  ...styles.buttonExport,
                  opacity: motores.length === 0 ? 0.6 : 1,
                }}
              >
                <Download size={16} />
                Exportar para Excel
              </button>
              <button
                onClick={() => document.getElementById("importFile").click()}
                style={{ ...styles.button, ...styles.buttonImport }}
              >
                <Upload size={16} />
                Importar do Excel
              </button>
            </div>

            <button
              onClick={gerarModeloPlanilha}
              style={{
                ...styles.button,
                width: "100%",
                backgroundColor: "#374151",
              }}
            >
              📋 Baixar Modelo de Planilha
            </button>
          </div>

          {/* Input de arquivo oculto */}
          <input
            id="importFile"
            type="file"
            accept=".csv,.xlsx,.xls"
            onChange={importarDeExcel}
            style={styles.fileInput}
          />

          {/* Lista de Motores */}
          <div>
            {motoresFiltrados.length === 0 ? (
              <div
                style={{ ...styles.card, textAlign: "center", padding: "40px" }}
              >
                <Database
                  size={48}
                  style={{ color: "#4b5563", margin: "0 auto 16px" }}
                />
                <p style={{ color: "#9ca3af", fontSize: "1.1rem" }}>
                  {searchTerm
                    ? "Nenhum motor encontrado"
                    : "Nenhum motor cadastrado"}
                </p>
                {!searchTerm && (
                  <div style={{ marginTop: "16px" }}>
                    <button
                      onClick={() => setActiveTab("cadastro")}
                      style={{
                        ...styles.button,
                        ...styles.buttonSuccess,
                        marginRight: "10px",
                      }}
                    >
                      Cadastrar Primeiro Motor
                    </button>
                    <button onClick={gerarModeloPlanilha} style={styles.button}>
                      📋 Usar Planilha
                    </button>
                  </div>
                )}
              </div>
            ) : (
              motoresFiltrados.map((motor) => (
                <div
                  key={motor.id}
                  onClick={() => setSelectedMotor(motor)}
                  style={{
                    ...styles.motorCard,
                    ...(selectedMotor?.id === motor.id && styles.motorSelected),
                  }}
                >
                  <div style={styles.motorHeader}>
                    <div>
                      <h3 style={styles.motorMarca}>{motor.marca}</h3>
                      <p style={styles.motorCarro}>{motor.carro}</p>
                      <p style={styles.motorMotor}>{motor.motor}</p>
                    </div>
                    <div style={styles.motorActions}>
                      <button
                        onClick={(e) => iniciarEdicao(motor)}
                        style={styles.buttonEdit}
                      >
                        <Edit size={14} />
                      </button>
                      <button
                        onClick={(e) => excluirMotor(motor.id, e)}
                        style={styles.buttonDanger}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>

                  <div style={styles.metricsGrid}>
                    <div style={styles.metricCard}>
                      <span style={styles.metricLabel}>FIXO</span>
                      <span style={styles.metricValue}>{motor.fixo}</span>
                    </div>
                    <div
                      style={{ ...styles.metricCard, ...styles.metricBiela }}
                    >
                      <span style={styles.metricLabel}>BIELA</span>
                      <span style={styles.metricValue}>{motor.biela}</span>
                    </div>
                    <div
                      style={{ ...styles.metricCard, ...styles.metricCurso }}
                    >
                      <span style={styles.metricLabel}>CURSO</span>
                      <span style={styles.metricValue}>{motor.curso}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* CALCULADORA COMPLETA */}
      {activeTab === "calculadora" && (
        <div style={styles.card}>
          <h2 style={{ color: "#60a5fa", marginBottom: "20px" }}>
            🧮 Calculadora de Retífica
          </h2>
          {selectedMotor ? (
            <div>
              {/* Informações do Motor Selecionado */}
              <div
                style={{
                  ...styles.card,
                  background:
                    "linear-gradient(90deg, #2563eb 0%, #4f46e5 100%)",
                  marginBottom: "20px",
                }}
              >
                <p style={{ fontSize: "1.2rem", fontWeight: "bold" }}>
                  {selectedMotor.marca}
                </p>
                <p style={{ color: "#dbeafe" }}>
                  {selectedMotor.carro} - {selectedMotor.motor}
                </p>
              </div>

              {/* Medidas STD */}
              <div style={styles.calcInfo}>
                <h3
                  style={{
                    color: "#fef3c7",
                    marginBottom: "15px",
                    textAlign: "center",
                  }}
                >
                  📏 Medidas Padrão (STD)
                </h3>
                <div style={styles.calcInfoRow}>
                  <span style={styles.calcInfoLabel}>Fixo:</span>
                  <span style={styles.calcInfoValue}>
                    {selectedMotor.fixo} mm
                  </span>
                </div>
                <div style={styles.calcInfoRow}>
                  <span style={styles.calcInfoLabel}>Biela:</span>
                  <span style={styles.calcInfoValue}>
                    {selectedMotor.biela} mm
                  </span>
                </div>
                <div style={styles.calcInfoRow}>
                  <span style={styles.calcInfoLabel}>Lateral:</span>
                  <span style={styles.calcInfoValue}>
                    {selectedMotor.lateral} mm
                  </span>
                </div>
                <div style={styles.calcInfoRow}>
                  <span style={styles.calcInfoLabel}>Curso:</span>
                  <span style={styles.calcInfoValue}>
                    {selectedMotor.curso} mm
                  </span>
                </div>
                <div style={styles.calcInfoRow}>
                  <span style={styles.calcInfoLabel}>Mancal:</span>
                  <span style={styles.calcInfoValue}>
                    {selectedMotor.mancal}
                  </span>
                </div>
              </div>

              {/* Tipo de Retífica */}
              <div style={{ ...styles.card, marginBottom: "20px" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "12px",
                    fontWeight: "600",
                    fontSize: "1.1rem",
                  }}
                >
                  Tipo de Retífica:
                </label>
                <div style={{ display: "flex", gap: "20px" }}>
                  <label
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "10px",
                      cursor: "pointer",
                      flex: 1,
                    }}
                  >
                    <input
                      type="radio"
                      value="biela"
                      checked={tipoRetifica === "biela"}
                      onChange={(e) => {
                        setTipoRetifica(e.target.value);
                        setMedidaAtual("");
                        setMedidaCorte("");
                        setResultadoCalc(null);
                      }}
                      style={{ width: "20px", height: "20px" }}
                    />
                    <div style={{ flex: 1 }}>
                      <span
                        style={{
                          fontWeight: "600",
                          color: "#eab308",
                          fontSize: "1rem",
                        }}
                      >
                        BIELA
                      </span>
                      <div style={{ fontSize: "0.9rem", color: "#9ca3af" }}>
                        STD: {selectedMotor.biela} mm
                      </div>
                    </div>
                  </label>
                  <label
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "10px",
                      cursor: "pointer",
                      flex: 1,
                    }}
                  >
                    <input
                      type="radio"
                      value="mancal"
                      checked={tipoRetifica === "mancal"}
                      onChange={(e) => {
                        setTipoRetifica(e.target.value);
                        setMedidaAtual("");
                        setMedidaCorte("");
                        setResultadoCalc(null);
                      }}
                      style={{ width: "20px", height: "20px" }}
                    />
                    <div style={{ flex: 1 }}>
                      <span
                        style={{
                          fontWeight: "600",
                          color: "#10b981",
                          fontSize: "1rem",
                        }}
                      >
                        MANCAL
                      </span>
                      <div style={{ fontSize: "0.9rem", color: "#9ca3af" }}>
                        STD: {selectedMotor.mancal}
                      </div>
                    </div>
                  </label>
                </div>
              </div>

              {/* Medida Atual */}
              <div style={{ marginBottom: "20px" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "8px",
                    fontWeight: "600",
                    fontSize: "1.1rem",
                  }}
                >
                  Medida Atual Encontrada:
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={medidaAtual}
                  onChange={(e) => setMedidaAtual(e.target.value)}
                  placeholder={`Ex: ${
                    tipoRetifica === "biela"
                      ? (selectedMotor.biela - 0.5).toFixed(2)
                      : "47.60"
                  }`}
                  style={{
                    ...styles.input,
                    fontSize: "1.1rem",
                    padding: "15px",
                  }}
                />
              </div>

              {/* Medida de Corte */}
              <div style={{ marginBottom: "25px" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "8px",
                    fontWeight: "600",
                    fontSize: "1.1rem",
                  }}
                >
                  Medida de Corte Desejada:
                </label>
                <select
                  value={medidaCorte}
                  onChange={(e) => setMedidaCorte(e.target.value)}
                  style={{
                    ...styles.input,
                    fontSize: "1.1rem",
                    padding: "15px",
                  }}
                >
                  <option value="">Selecione a medida de corte</option>
                  {[0.25, 0.5, 0.75, 1.0].map((medida) => {
                    const medidaStd =
                      tipoRetifica === "biela"
                        ? selectedMotor.biela
                        : parseFloat(selectedMotor.mancal.split("/")[0]);
                    const valorCorte = (medidaStd - medida).toFixed(2);
                    return (
                      <option key={medida} value={valorCorte}>
                        {valorCorte} mm (-{medida.toFixed(2)} mm do STD)
                      </option>
                    );
                  })}
                </select>
              </div>

              {/* Botão Calcular */}
              <button
                onClick={calcularDeslocamento}
                disabled={!medidaAtual || !medidaCorte}
                style={{
                  ...styles.button,
                  ...styles.buttonSuccess,
                  width: "100%",
                  padding: "18px",
                  fontSize: "1.2rem",
                  opacity: !medidaAtual || !medidaCorte ? 0.6 : 1,
                }}
              >
                <Calculator size={20} />
                Calcular Deslocamento
              </button>

              {/* Resultado */}
              {resultadoCalc && (
                <div
                  style={{
                    ...styles.card,
                    background:
                      "linear-gradient(90deg, #7c3aed 0%, #ec4899 100%)",
                    marginTop: "25px",
                  }}
                >
                  <h3
                    style={{
                      textAlign: "center",
                      marginBottom: "20px",
                      fontSize: "1.3rem",
                    }}
                  >
                    📊 Resultado do Cálculo
                  </h3>

                  <div
                    style={{
                      backgroundColor: "rgba(255,255,255,0.1)",
                      borderRadius: "10px",
                      padding: "20px",
                      marginBottom: "20px",
                    }}
                  >
                    <div style={styles.calcInfoRow}>
                      <span style={styles.calcInfoLabel}>Tipo:</span>
                      <span
                        style={{ ...styles.calcInfoValue, fontSize: "1.1rem" }}
                      >
                        {resultadoCalc.tipo}
                      </span>
                    </div>
                    <div style={styles.calcInfoRow}>
                      <span style={styles.calcInfoLabel}>Medida STD:</span>
                      <span style={styles.calcInfoValue}>
                        {resultadoCalc.medidaStd} mm
                      </span>
                    </div>
                    <div style={styles.calcInfoRow}>
                      <span style={styles.calcInfoLabel}>Medida Atual:</span>
                      <span style={styles.calcInfoValue}>
                        {resultadoCalc.medidaAtual} mm
                      </span>
                    </div>
                    <div style={styles.calcInfoRow}>
                      <span style={styles.calcInfoLabel}>Medida Corte:</span>
                      <span style={styles.calcInfoValue}>
                        {resultadoCalc.medidaCorte} mm
                      </span>
                    </div>
                  </div>

                  <div
                    style={{
                      backgroundColor: "rgba(255,255,255,0.15)",
                      borderRadius: "10px",
                      padding: "20px",
                    }}
                  >
                    <div style={styles.calcInfoRow}>
                      <span style={styles.calcInfoLabel}>
                        🔧 Deslocamento Necessário:
                      </span>
                      <span
                        style={{
                          ...styles.calcInfoValue,
                          fontSize: "1.4rem",
                          color: "#fef3c7",
                        }}
                      >
                        {resultadoCalc.deslocamento} mm
                      </span>
                    </div>
                    <div style={styles.calcInfoRow}>
                      <span style={styles.calcInfoLabel}>⚖️ Contrapeso:</span>
                      <span style={styles.calcInfoValue}>
                        {resultadoCalc.contraPeso} mm
                      </span>
                    </div>
                    <div style={styles.calcInfoRow}>
                      <span style={styles.calcInfoLabel}>📏 Curso:</span>
                      <span style={styles.calcInfoValue}>
                        {resultadoCalc.curso} mm
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div style={{ textAlign: "center", padding: "40px" }}>
              <Calculator
                size={48}
                style={{ color: "#4b5563", margin: "0 auto 16px" }}
              />
              <p style={{ color: "#9ca3af", fontSize: "1.1rem" }}>
                Selecione um motor na aba "Consulta" para usar a calculadora
              </p>
              <button
                onClick={() => setActiveTab("consulta")}
                style={{
                  ...styles.button,
                  ...styles.buttonSuccess,
                  marginTop: "16px",
                }}
              >
                Ir para Consulta
              </button>
            </div>
          )}
        </div>
      )}

      {/* CADASTRO/EDIÇÃO */}
      {(activeTab === "cadastro" || mostrarFormEdicao) && (
        <div style={styles.card}>
          <h2 style={{ color: "#60a5fa", marginBottom: "20px" }}>
            {mostrarFormEdicao ? "✏️ Editar Motor" : "📝 Cadastrar Novo Motor"}
          </h2>

          <div style={styles.formGrid}>
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "8px",
                  fontWeight: "600",
                }}
              >
                Marca *
              </label>
              <input
                type="text"
                value={novoMotor.marca}
                onChange={(e) =>
                  setNovoMotor({ ...novoMotor, marca: e.target.value })
                }
                placeholder="Ex: PALIO/UNO/SIENA"
                style={styles.input}
              />
            </div>
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "8px",
                  fontWeight: "600",
                }}
              >
                Carro *
              </label>
              <input
                type="text"
                value={novoMotor.carro}
                onChange={(e) =>
                  setNovoMotor({ ...novoMotor, carro: e.target.value })
                }
                placeholder="Ex: FIRE 1.0 141C2000"
                style={styles.input}
              />
            </div>
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "8px",
                  fontWeight: "600",
                }}
              >
                Motor *
              </label>
              <input
                type="text"
                value={novoMotor.motor}
                onChange={(e) =>
                  setNovoMotor({ ...novoMotor, motor: e.target.value })
                }
                placeholder="Ex: 48,00"
                style={styles.input}
              />
            </div>
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "8px",
                  fontWeight: "600",
                }}
              >
                Fixo
              </label>
              <input
                type="number"
                step="0.01"
                value={novoMotor.fixo}
                onChange={(e) =>
                  setNovoMotor({ ...novoMotor, fixo: e.target.value })
                }
                placeholder="Ex: 38.00"
                style={styles.input}
              />
            </div>
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "8px",
                  fontWeight: "600",
                }}
              >
                Biela *
              </label>
              <input
                type="number"
                step="0.01"
                value={novoMotor.biela}
                onChange={(e) =>
                  setNovoMotor({ ...novoMotor, biela: e.target.value })
                }
                placeholder="Ex: 24.00"
                style={styles.input}
              />
            </div>
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "8px",
                  fontWeight: "600",
                }}
              >
                Lateral
              </label>
              <input
                type="number"
                step="0.01"
                value={novoMotor.lateral}
                onChange={(e) =>
                  setNovoMotor({ ...novoMotor, lateral: e.target.value })
                }
                placeholder="Ex: 32.45"
                style={styles.input}
              />
            </div>
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "8px",
                  fontWeight: "600",
                }}
              >
                Curso *
              </label>
              <input
                type="number"
                step="0.01"
                value={novoMotor.curso}
                onChange={(e) =>
                  setNovoMotor({ ...novoMotor, curso: e.target.value })
                }
                placeholder="Ex: 21.00"
                style={styles.input}
              />
            </div>
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "8px",
                  fontWeight: "600",
                }}
              >
                Mancal
              </label>
              <input
                type="text"
                value={novoMotor.mancal}
                onChange={(e) =>
                  setNovoMotor({ ...novoMotor, mancal: e.target.value })
                }
                placeholder="Ex: 78,70"
                style={styles.input}
              />
            </div>
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "8px",
                  fontWeight: "600",
                }}
              >
                Diâmetro
              </label>
              <input
                type="text"
                value={novoMotor.diametro}
                onChange={(e) =>
                  setNovoMotor({ ...novoMotor, diametro: e.target.value })
                }
                placeholder="Ex: 70,00X64,90"
                style={styles.input}
              />
            </div>
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "8px",
                  fontWeight: "600",
                }}
              >
                Altura
              </label>
              <input
                type="text"
                value={novoMotor.altura}
                onChange={(e) =>
                  setNovoMotor({ ...novoMotor, altura: e.target.value })
                }
                placeholder="Ex: 41,12/41,14"
                style={styles.input}
              />
            </div>
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "8px",
                  fontWeight: "600",
                }}
              >
                Ferro
              </label>
              <input
                type="text"
                value={novoMotor.ferro}
                onChange={(e) =>
                  setNovoMotor({ ...novoMotor, ferro: e.target.value })
                }
                placeholder="Ex: 70,00"
                style={styles.input}
              />
            </div>
          </div>

          <div style={{ display: "flex", gap: "10px", marginTop: "20px" }}>
            <button
              onClick={editandoMotor ? salvarEdicao : salvarMotor}
              style={{ ...styles.button, ...styles.buttonSuccess, flex: 1 }}
            >
              <CheckCircle2 size={18} />
              {editandoMotor ? "Salvar Edição" : "Cadastrar Motor"}
            </button>

            {editandoMotor && (
              <button
                onClick={cancelarEdicao}
                style={{
                  ...styles.button,
                  backgroundColor: "#6b7280",
                  flex: 0.5,
                }}
              >
                <X size={18} />
                Cancelar
              </button>
            )}
          </div>

          <p
            style={{
              color: "#9ca3af",
              fontSize: "0.875rem",
              marginTop: "15px",
            }}
          >
            * Campos obrigatórios
          </p>
        </div>
      )}
    </div>
  );
};

export default RetificadoraApp;
